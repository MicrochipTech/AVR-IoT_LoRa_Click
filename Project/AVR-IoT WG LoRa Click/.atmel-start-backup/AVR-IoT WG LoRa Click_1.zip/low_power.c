/*
    \file   low_power.c

    \brief  low power handler source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include "low_power.h"
#include "lora_handling.h"
#include "atmel_start_pins.h"
#include "clock_config.h"
#include "lora2_click.h"
#include "driver_rn2903.h"
#include "led.h"
#include "usart_basic.h"
#include <util/delay.h>
#include <avr/sleep.h>
#include <ccp.h>

#define HAS_ENTERED_LOW_POWER_AT_LEAST_ONCE     1
#define SHORT_DELAY                             2
#define MEDIUM_DELAY                            15
#define LONG_DELAY                              1000
#define BREAK_CONDITION                         0x00
#define WAKE_UP_STRING                          0x55
#define SLEEP_TIME                              "100000000"

static void Init_low_power(void);
static void Deinit_low_power(void);
static void TCB_disable(void);
static void TCB_enable(void);

extern void Create_command(const char* command, const char* value);

extern const char RN_cmd_sys_sleep[];
extern char response[];
extern char complete_command[];
extern uint8_t has_entered_low_power_at_least_once;

static void Init_low_power(void)
{
    _PROTECTED_WRITE(CLKCTRL.MCLKCTRLB,
    CLKCTRL_PDIV_64X_gc /* 64 */
    | 1 << CLKCTRL_PEN_bp ); /* Prescaler enable: enabled */

    _PROTECTED_WRITE(CLKCTRL.MCLKCTRLA,
    CLKCTRL_CLKSEL_OSCULP32K_gc ); /* 32KHz Internal Ultra Low Power Oscillator (OSCULP32K) */

    /* wait for system oscillator changing to finish */
    while (CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm)
    {
        ;
    }
}

static void Deinit_low_power(void)
{
    _PROTECTED_WRITE(CLKCTRL.MCLKCTRLB,
    CLKCTRL_PDIV_4X_gc /* 4 */
    | 1 << CLKCTRL_PEN_bp ); /* Prescaler enable: enabled */

    _PROTECTED_WRITE(CLKCTRL.MCLKCTRLA,
    CLKCTRL_CLKSEL_OSC20M_gc ); /* 20MHz main oscillator */

    /* wait for system oscillator changing to finish */
    while (CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm)
    {
        ;
    }
}

void Disable_WINC(void)
{
    PF3_set_level(0);
}

static void TCB_disable(void)
{
    TCB0.CTRLA &= ~(1 << TCB_ENABLE_bp);
}

static void TCB_enable(void)
{
    TCB0.CTRLA |= (1 << TCB_ENABLE_bp);
}

void Enter_Low_Power(void)
{
    Create_command(RN_cmd_sys_sleep, SLEEP_TIME);
    rn2903_SendString(complete_command);
    has_entered_low_power_at_least_once = HAS_ENTERED_LOW_POWER_AT_LEAST_ONCE;
    LoRa2_ReadyReceiveBuffer();
    LED_YELLOW_set_level(LED_OFF);
    LoRa2_blockingWait(MEDIUM_DELAY);
    Init_low_power();
    TCB_enable();
    sleep_mode();
}

void Exit_Low_Power(void)
{
    TCB_disable();
    Deinit_low_power();
    LED_YELLOW_set_level(LED_ON);
    if(has_entered_low_power_at_least_once == HAS_ENTERED_LOW_POWER_AT_LEAST_ONCE)
    {
        USART_ASYNC_write(BREAK_CONDITION);
        USART_ASYNC_write(WAKE_UP_STRING);
    }
    LoRa2_blockingWait(MEDIUM_DELAY);
}
