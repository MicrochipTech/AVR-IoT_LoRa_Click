/*
 * application_manager.h
 *
 * Created: 10/4/2018 1:36:20 PM
 *  Author: I17643
 */

#ifndef APPLICATION_MANAGER_H_
#define APPLICATION_MANAGER_H_

void application_init(void);

#endif /* APPLICATION_MANAGER_H_ */
