/*
 * application_manager.c
 *
 * Created: 10/4/2018 1:37:19 PM
 *  Author: I17643
 */

#include <string.h>
#include <time.h>
#include <stdio.h>
#include <atomic.h>
#include <avr/wdt.h>
#include "application_manager.h"
#include "atmel_start_pins.h"
#include "atmel_start.h"
#include "led.h"


#define MAIN_DATATASK_INTERVAL 100

void application_init()
{
	wdt_disable();

	// Initialization of modules before interrupts are enabled
	atmel_start_init();

	LED_test();

	ENABLE_INTERRUPTS();

}


