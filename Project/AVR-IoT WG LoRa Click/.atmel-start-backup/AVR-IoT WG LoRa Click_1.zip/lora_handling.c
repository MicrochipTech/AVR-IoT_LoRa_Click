/*
    \file   lora_handling.c

    \brief  lora handler source file.

    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "atmel_start_pins.h"
#include "led.h"
#include "sensors_handling.h"
#include <util/delay.h>
#include "lora2_click.h"
#include "driver_rn2903.h"
#include "lora_handling.h"

#define OTAA                                    1
//#define APB                                   1
#define NO_FREE_CH                              "no_free_ch\r\n"
#define OK                                      "ok\r\n"
#define ACCEPTED                                "accepted\r\n"
#define FIRST_CHARACTER                         0
#define RESPONSE_LENGTH                         30
#define TRANSMISSION_LENGTH                     100
#define COMMAND_LENGTH                          100
#define SHORT_DELAY                             2
#define MEDIUM_DELAY                            15
#define LONG_DELAY                              1000
#define EQUALS_NO_FREE_CH                       0
#define EQUALS_OK                               0
#define EQUALS_ACCEPTED                         0
#define TEMPERATURE_MAGNITUDE                   100
#define HAS_ENTERED_LOW_POWER_AT_LEAST_ONCE     1
#define NO_CHAR_YET                             0

static void Handle_response(void);
static void Loop_until_ok(const char* command);
static void Read_sensors(void);
static void Create_transmission(void);

#ifdef OTAA

const char RN_cmd_deveui[] = "mac set deveui";
const char RN_cmd_appeui[] = "mac set appeui";
const char RN_cmd_appkey[] = "mac set appkey";

const char my_deveui[] = "00B5BB3C10A7350E";
const char my_appeui[] = "70B3D57ED0013395";
const char my_appkey[] = "B8A47334FF700335DD5CB647DBFBD552";

const char RN_cmd_join_otaa[] = "mac join otaa";

#endif

#ifdef APB

const char RN_cmd_devaddr[] = "mac set devaddr";
const char RN_cmd_nwkskey[] = "mac set nwkskey";
const char RN_cmd_appskey[] = "mac set appskey";

const char my_devaddr[] = "26052B8D";
const char my_nwkskey[] = "4AE4AABFB86F91E622E33015EA77036D";
const char my_appskey[] = "D545FDC9C25B84BEE186733D254B9B93";

const char RN_cmd_join_abp[] = "mac join abp";

#endif

const char RN_cmd_mac_save[] = "mac save";
const char RN_cmd_mac_set_dr[] = "mac set dr 5";
const char RN_cmd_sys_sleep[] = "sys sleep";
const char RN_cmd_mac_tx[] = "mac tx";
const char confirmed_transmission[] = "cnf 1";

char response[RESPONSE_LENGTH];
char complete_command[COMMAND_LENGTH];
char transmission_command[TRANSMISSION_LENGTH];
uint8_t has_entered_low_power_at_least_once;
uint16_t light_value;
uint8_t temperature;

void Create_command(const char* command, const char* value)
{
    snprintf(complete_command, sizeof complete_command, "%s %s", command, value);
}

static void Handle_response(void)
{
    do
    {
        strcpy(response,LoRa2_GetResponse());
    }while(response[FIRST_CHARACTER] == NO_CHAR_YET);
    
    LoRa2_blockingWait(SHORT_DELAY);
    strcpy(response,LoRa2_GetResponse());
    printf("%s", response);
}

static void Loop_until_ok(const char* command_to_be_sent)
{
    do
    {
        LoRa2_ReadyReceiveBuffer();
        
        rn2903_SendString(command_to_be_sent);

        Handle_response();
        
        if(strcmp(response, NO_FREE_CH) == EQUALS_NO_FREE_CH)
        {
            LoRa2_blockingWait(LONG_DELAY);
        }
    }while(strcmp(response, OK) != EQUALS_OK);
}

void LoRa_Init(void) // Call After System Init; Above while(1) Loop in Main.c
{
    
    LoRa2_RegisterISRCallback();
    LoRa2_blockingWait(SHORT_DELAY);
    
    LED_BLUE_set_level(LED_ON);
    rn2903_SetHardwareReset(false);
    LoRa2_blockingWait(SHORT_DELAY);
    rn2903_SetHardwareReset(true);
    LoRa2_blockingWait(MEDIUM_DELAY);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    
    #ifdef OTAA

    Create_command(RN_cmd_deveui, my_deveui);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    Create_command(RN_cmd_appeui, my_appeui);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    Create_command(RN_cmd_appkey, my_appkey);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    
    #endif

    #ifdef APB
    
    Create_command(RN_cmd_devaddr, my_devaddr);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    Create_command(RN_cmd_nwkskey, my_nwkskey);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();
    Create_command(RN_cmd_appskey, my_appskey);
    rn2903_SendString(complete_command);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();

    #endif

    rn2903_SendString(RN_cmd_mac_set_dr);
    LoRa2_blockingWait(SHORT_DELAY);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();

    rn2903_SendString(RN_cmd_mac_save);
    LoRa2_blockingWait(LONG_DELAY);
    Handle_response();
    LoRa2_ReadyReceiveBuffer();

    do
    {  //rejoins until the message is "accepted" instead of "denied"
        
        #ifdef OTAA
        
        Loop_until_ok(RN_cmd_join_otaa);
        
        #endif
        
        #ifdef APB
        
        Loop_until_ok(RN_cmd_join_abp);
        
        #endif
        
        LoRa2_ReadyReceiveBuffer();
        Handle_response();

    }while(strcmp(response, ACCEPTED) != EQUALS_ACCEPTED);

    LED_BLUE_set_level(LED_OFF);
}

static void Read_sensors(void)
{
    light_value = SENSORS_getLightValue();
    temperature = SENSORS_getTempValue() / TEMPERATURE_MAGNITUDE;
}

static void Create_transmission(void)
{
    Read_sensors();
    Create_command(RN_cmd_mac_tx, confirmed_transmission);
    //adds the value in HEX to the message
    snprintf(transmission_command, sizeof transmission_command, "%s %x%x", complete_command, light_value, temperature);
}

void Send_transmission(void)
{
    
    if(has_entered_low_power_at_least_once == HAS_ENTERED_LOW_POWER_AT_LEAST_ONCE)
    {
        LoRa2_blockingWait(MEDIUM_DELAY);
        Handle_response();
        LoRa2_blockingWait(SHORT_DELAY);
    }

    Create_transmission();

    Loop_until_ok(transmission_command);

    LoRa2_blockingWait(SHORT_DELAY);
    LoRa2_ReadyReceiveBuffer();

    Handle_response();
}